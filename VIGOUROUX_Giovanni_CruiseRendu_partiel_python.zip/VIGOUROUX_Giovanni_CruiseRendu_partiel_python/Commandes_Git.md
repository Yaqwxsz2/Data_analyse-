# Ensemble des instructions git permettant de push les fichiers depuis  un repository local 

# 1) git init

# 2) git add ['VIGOUROUX_Giovanni_Cruise_Partiel_Python-Git.ipynb']

# 3) git remote add origin https://github.com/Yaqwxsz2/VIGOUROUX_Giovanni_Partiel_python.git

# 4) git pull origin master

# 5) git push origin master
